package clientonline;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.JToggleButton;

public class ShovonBPanel extends JPanel {

    public ShovonBPanel() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        tb01 = new javax.swing.JToggleButton();
        tb02 = new javax.swing.JToggleButton();
        tb03 = new javax.swing.JToggleButton();
        tb04 = new javax.swing.JToggleButton();
        tb05 = new javax.swing.JToggleButton();
        tb06 = new javax.swing.JToggleButton();
        tb07 = new javax.swing.JToggleButton();
        tb08 = new javax.swing.JToggleButton();
        tb09 = new javax.swing.JToggleButton();
        tb10 = new javax.swing.JToggleButton();
        tb11 = new javax.swing.JToggleButton();
        tb12 = new javax.swing.JToggleButton();
        tb13 = new javax.swing.JToggleButton();
        tb14 = new javax.swing.JToggleButton();
        tb15 = new javax.swing.JToggleButton();
        tb16 = new javax.swing.JToggleButton();
        tb17 = new javax.swing.JToggleButton();
        tb18 = new javax.swing.JToggleButton();
        tb19 = new javax.swing.JToggleButton();
        tb20 = new javax.swing.JToggleButton();
        tb21 = new javax.swing.JToggleButton();
        tb22 = new javax.swing.JToggleButton();
        tb23 = new javax.swing.JToggleButton();
        tb24 = new javax.swing.JToggleButton();
        tb25 = new javax.swing.JToggleButton();
        tb26 = new javax.swing.JToggleButton();
        tb27 = new javax.swing.JToggleButton();
        tb28 = new javax.swing.JToggleButton();
        tb29 = new javax.swing.JToggleButton();
        tb30 = new javax.swing.JToggleButton();
        tb31 = new javax.swing.JToggleButton();
        tb32 = new javax.swing.JToggleButton();
        tb33 = new javax.swing.JToggleButton();
        tb34 = new javax.swing.JToggleButton();
        tb35 = new javax.swing.JToggleButton();
        tb36 = new javax.swing.JToggleButton();
        tb37 = new javax.swing.JToggleButton();
        tb38 = new javax.swing.JToggleButton();
        tb39 = new javax.swing.JToggleButton();
        tb40 = new javax.swing.JToggleButton();
        tb41 = new javax.swing.JToggleButton();
        tb42 = new javax.swing.JToggleButton();
        tb43 = new javax.swing.JToggleButton();
        tb44 = new javax.swing.JToggleButton();
        tb45 = new javax.swing.JToggleButton();
        tb46 = new javax.swing.JToggleButton();
        tb47 = new javax.swing.JToggleButton();
        tb48 = new javax.swing.JToggleButton();
        tb49 = new javax.swing.JToggleButton();
        tb50 = new javax.swing.JToggleButton();

        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        java.awt.GridBagLayout layout = new java.awt.GridBagLayout();
        layout.columnWidths = new int[] {0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0};
        layout.rowHeights = new int[] {0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0};
        setLayout(layout);

        tb01.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb01.setText("01");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        add(tb01, gridBagConstraints);

        tb02.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb02.setText("02");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        add(tb02, gridBagConstraints);

        tb03.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb03.setText("03");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 18;
        add(tb03, gridBagConstraints);

        tb04.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb04.setText("04");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 24;
        add(tb04, gridBagConstraints);

        tb05.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb05.setText("05");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 30;
        add(tb05, gridBagConstraints);

        tb06.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb06.setText("06");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 0;
        add(tb06, gridBagConstraints);

        tb07.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb07.setText("07");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 6;
        add(tb07, gridBagConstraints);

        tb08.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb08.setText("08");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 18;
        add(tb08, gridBagConstraints);

        tb09.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb09.setText("09");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 24;
        add(tb09, gridBagConstraints);

        tb10.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb10.setText("10");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 30;
        add(tb10, gridBagConstraints);

        tb11.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb11.setText("11");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 12;
        gridBagConstraints.gridy = 0;
        add(tb11, gridBagConstraints);

        tb12.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb12.setText("12");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 12;
        gridBagConstraints.gridy = 6;
        add(tb12, gridBagConstraints);

        tb13.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb13.setText("13");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 12;
        gridBagConstraints.gridy = 18;
        add(tb13, gridBagConstraints);

        tb14.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb14.setText("14");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 12;
        gridBagConstraints.gridy = 24;
        add(tb14, gridBagConstraints);

        tb15.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb15.setText("15");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 12;
        gridBagConstraints.gridy = 30;
        add(tb15, gridBagConstraints);

        tb16.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb16.setText("16");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 18;
        gridBagConstraints.gridy = 0;
        add(tb16, gridBagConstraints);

        tb17.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb17.setText("17");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 18;
        gridBagConstraints.gridy = 6;
        add(tb17, gridBagConstraints);

        tb18.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb18.setText("18");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 18;
        gridBagConstraints.gridy = 18;
        add(tb18, gridBagConstraints);

        tb19.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb19.setText("19");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 18;
        gridBagConstraints.gridy = 24;
        add(tb19, gridBagConstraints);

        tb20.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb20.setText("20");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 18;
        gridBagConstraints.gridy = 30;
        add(tb20, gridBagConstraints);

        tb21.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb21.setText("21");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 24;
        gridBagConstraints.gridy = 0;
        add(tb21, gridBagConstraints);

        tb22.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb22.setText("22");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 24;
        gridBagConstraints.gridy = 6;
        add(tb22, gridBagConstraints);

        tb23.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb23.setText("23");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 24;
        gridBagConstraints.gridy = 18;
        add(tb23, gridBagConstraints);

        tb24.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb24.setText("24");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 24;
        gridBagConstraints.gridy = 24;
        add(tb24, gridBagConstraints);

        tb25.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb25.setText("25");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 24;
        gridBagConstraints.gridy = 30;
        add(tb25, gridBagConstraints);

        tb26.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb26.setText("26");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 36;
        gridBagConstraints.gridy = 0;
        add(tb26, gridBagConstraints);

        tb27.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb27.setText("27");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 36;
        gridBagConstraints.gridy = 6;
        add(tb27, gridBagConstraints);

        tb28.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb28.setText("28");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 36;
        gridBagConstraints.gridy = 18;
        add(tb28, gridBagConstraints);

        tb29.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb29.setText("29");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 36;
        gridBagConstraints.gridy = 24;
        add(tb29, gridBagConstraints);

        tb30.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb30.setText("30");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 36;
        gridBagConstraints.gridy = 30;
        add(tb30, gridBagConstraints);

        tb31.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb31.setText("31");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 42;
        gridBagConstraints.gridy = 0;
        add(tb31, gridBagConstraints);

        tb32.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb32.setText("32");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 42;
        gridBagConstraints.gridy = 6;
        add(tb32, gridBagConstraints);

        tb33.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb33.setText("33");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 42;
        gridBagConstraints.gridy = 18;
        add(tb33, gridBagConstraints);

        tb34.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb34.setText("34");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 42;
        gridBagConstraints.gridy = 24;
        add(tb34, gridBagConstraints);

        tb35.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb35.setText("35");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 42;
        gridBagConstraints.gridy = 30;
        add(tb35, gridBagConstraints);

        tb36.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb36.setText("36");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 48;
        gridBagConstraints.gridy = 0;
        add(tb36, gridBagConstraints);

        tb37.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb37.setText("37");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 48;
        gridBagConstraints.gridy = 6;
        add(tb37, gridBagConstraints);

        tb38.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb38.setText("38");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 48;
        gridBagConstraints.gridy = 18;
        add(tb38, gridBagConstraints);

        tb39.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb39.setText("39");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 48;
        gridBagConstraints.gridy = 24;
        add(tb39, gridBagConstraints);

        tb40.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb40.setText("40");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 48;
        gridBagConstraints.gridy = 30;
        add(tb40, gridBagConstraints);

        tb41.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb41.setText("41");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 54;
        gridBagConstraints.gridy = 0;
        add(tb41, gridBagConstraints);

        tb42.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb42.setText("42");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 54;
        gridBagConstraints.gridy = 6;
        add(tb42, gridBagConstraints);

        tb43.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb43.setText("43");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 54;
        gridBagConstraints.gridy = 18;
        add(tb43, gridBagConstraints);

        tb44.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb44.setText("44");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 54;
        gridBagConstraints.gridy = 24;
        add(tb44, gridBagConstraints);

        tb45.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb45.setText("45");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 54;
        gridBagConstraints.gridy = 30;
        add(tb45, gridBagConstraints);

        tb46.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb46.setText("46");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 60;
        gridBagConstraints.gridy = 0;
        add(tb46, gridBagConstraints);

        tb47.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb47.setText("47");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 60;
        gridBagConstraints.gridy = 6;
        add(tb47, gridBagConstraints);

        tb48.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb48.setText("48");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 60;
        gridBagConstraints.gridy = 18;
        add(tb48, gridBagConstraints);

        tb49.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb49.setText("49");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 60;
        gridBagConstraints.gridy = 24;
        add(tb49, gridBagConstraints);

        tb50.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        tb50.setText("50");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 60;
        gridBagConstraints.gridy = 30;
        add(tb50, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton tb01;
    private javax.swing.JToggleButton tb02;
    private javax.swing.JToggleButton tb03;
    private javax.swing.JToggleButton tb04;
    private javax.swing.JToggleButton tb05;
    private javax.swing.JToggleButton tb06;
    private javax.swing.JToggleButton tb07;
    private javax.swing.JToggleButton tb08;
    private javax.swing.JToggleButton tb09;
    private javax.swing.JToggleButton tb10;
    private javax.swing.JToggleButton tb11;
    private javax.swing.JToggleButton tb12;
    private javax.swing.JToggleButton tb13;
    private javax.swing.JToggleButton tb14;
    private javax.swing.JToggleButton tb15;
    private javax.swing.JToggleButton tb16;
    private javax.swing.JToggleButton tb17;
    private javax.swing.JToggleButton tb18;
    private javax.swing.JToggleButton tb19;
    private javax.swing.JToggleButton tb20;
    private javax.swing.JToggleButton tb21;
    private javax.swing.JToggleButton tb22;
    private javax.swing.JToggleButton tb23;
    private javax.swing.JToggleButton tb24;
    private javax.swing.JToggleButton tb25;
    private javax.swing.JToggleButton tb26;
    private javax.swing.JToggleButton tb27;
    private javax.swing.JToggleButton tb28;
    private javax.swing.JToggleButton tb29;
    private javax.swing.JToggleButton tb30;
    private javax.swing.JToggleButton tb31;
    private javax.swing.JToggleButton tb32;
    private javax.swing.JToggleButton tb33;
    private javax.swing.JToggleButton tb34;
    private javax.swing.JToggleButton tb35;
    private javax.swing.JToggleButton tb36;
    private javax.swing.JToggleButton tb37;
    private javax.swing.JToggleButton tb38;
    private javax.swing.JToggleButton tb39;
    private javax.swing.JToggleButton tb40;
    private javax.swing.JToggleButton tb41;
    private javax.swing.JToggleButton tb42;
    private javax.swing.JToggleButton tb43;
    private javax.swing.JToggleButton tb44;
    private javax.swing.JToggleButton tb45;
    private javax.swing.JToggleButton tb46;
    private javax.swing.JToggleButton tb47;
    private javax.swing.JToggleButton tb48;
    private javax.swing.JToggleButton tb49;
    private javax.swing.JToggleButton tb50;
    // End of variables declaration//GEN-END:variables

 
    public String [] getSeatList(){
        
        final JToggleButton[] jtb = {tb01, tb02, tb03, tb04, tb05, tb06, tb07, 
        tb08, tb09, tb10, tb11, tb12, tb13, tb14, tb15, tb16, tb17, tb18, tb19, tb20,
                          tb21, tb22, tb23, tb24, tb25, tb26, tb27, tb28, tb29, tb30,
                          tb31, tb32, tb33, tb34, tb35, tb36, tb37, tb38, tb39, tb40, 
                          tb41, tb42, tb43, tb44, tb45, tb46, tb47, tb48, tb49, tb50};
        
        final ArrayList<String> temp = new ArrayList<>();
        
        for (JToggleButton jtb1 : jtb) {
            if (jtb1.isSelected()) {
                temp.add(jtb1.getText());
            }
        }
        
        String [] shovonBList = new String[temp.size()];
        shovonBList = temp.toArray(shovonBList);
        
        return shovonBList;
        
    }
        
     public void setSeatsList(String[] seatList){
        final JToggleButton[] jtb = {tb01, tb02, tb03, tb04, tb05, tb06, tb07, 
        tb08, tb09, tb10, tb11, tb12, tb13, tb14, tb15, tb16, tb17, tb18, tb19, tb20,
                          tb21, tb22, tb23, tb24, tb25, tb26, tb27, tb28, tb29, tb30,
                          tb31, tb32, tb33, tb34, tb35, tb36, tb37, tb38, tb39, tb40, 
                          tb41, tb42, tb43, tb44, tb45, tb46, tb47, tb48, tb49, tb50};
        
        for (String seatList1 : seatList) {
            for (JToggleButton jtb1 : jtb) {
                if (seatList1 == null ? jtb1.getText() == null : seatList1.equals(jtb1.getText())) {
                    jtb1.setVisible(false);
                }
            }
        }
        
        
    }
      
        
        
}